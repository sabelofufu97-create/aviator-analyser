package com.example.aviatoranalyser

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.InputType
import java.util.Locale
import kotlin.math.max

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 13, 27)
    private val panel = Color.rgb(33, 27, 48)
    private val panel2 = Color.rgb(56, 42, 73)
    private val gold = Color.rgb(255, 202, 66)
    private val red = Color.rgb(255, 100, 100)
    private val green = Color.rgb(72, 232, 154)
    private val muted = Color.rgb(177, 169, 190)
    private val prefs by lazy { getSharedPreferences("aviator_data", Context.MODE_PRIVATE) }
    private val results = mutableListOf<Double>()

    private lateinit var averageText: TextView
    private lateinit var aboveText: TextView
    private lateinit var totalText: TextView
    private lateinit var historyBox: LinearLayout
    private lateinit var signalText: TextView
    private lateinit var analysisText: TextView
    private lateinit var multiplierInput: EditText
    private lateinit var windowSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadResults()
        buildScreen()
        refresh()
    }

    private fun loadResults() {
        val saved = prefs.getString("results", "") ?: ""
        if (saved.isNotBlank()) saved.split(",").forEach {
            it.toDoubleOrNull()?.takeIf { n -> n >= 1.0 }?.let(results::add)
        }
    }

    private fun saveResults() {
        prefs.edit().putString("results", results.joinToString(",")).apply()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }
        scroll.addView(page)
        setContentView(scroll)

        val header = TextView(this).apply {
            text = "✈  AVIATOR ANALYSER"
            textSize = 23f
            setTextColor(Color.rgb(255, 59, 69))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(20))
        }
        page.addView(header)

        val trendCard = card(page)
        label(trendCard, "TREND ANALYSIS")
        signalText = TextView(this).apply {
            text = "WAITING"
            textSize = 34f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(gold)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(4))
        }
        trendCard.addView(signalText)
        analysisText = TextView(this).apply {
            text = "Add previous multipliers, then analyse the history."
            textSize = 14f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }
        trendCard.addView(analysisText)

        val entryCard = card(page)
        title(entryCard, "Add crash result")
        multiplierInput = EditText(this).apply {
            hint = "Example: 2.45"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            textSize = 18f
            gravity = Gravity.CENTER
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(muted)
            background = rounded(Color.rgb(245, 243, 249), 10)
            setPadding(dp(12), dp(11), dp(12), dp(11))
        }
        entryCard.addView(multiplierInput, matchWrap())
        button(entryCard, "ADD RESULT", red) { addResult() }
        title(entryCard, "Analysis window")
        windowSpinner = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Last 5 results", "Last 10 results", "Last 20 results", "Last 50 results"))
        windowSpinner.adapter = adapter
        entryCard.addView(windowSpinner, matchWrap())
        button(entryCard, "ANALYSE HISTORY", gold, Color.rgb(30, 22, 35)) { analyse() }

        val statsCard = card(page)
        title(statsCard, "Statistics")
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        averageText = statColumn(stats, "0.00x", "Average")
        aboveText = statColumn(stats, "0", "Above 2x")
        totalText = statColumn(stats, "0", "Rounds")
        statsCard.addView(stats)

        val historyCard = card(page)
        title(historyCard, "Recent history")
        historyBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        historyCard.addView(historyBox)
        button(historyCard, "CLEAR HISTORY", panel2) {
            AlertDialog.Builder(this)
                .setTitle("Clear saved history?")
                .setMessage("This permanently deletes all locally saved results.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("CLEAR") { _, _ ->
                    results.clear()
                    saveResults()
                    resetAnalysis()
                    refresh()
                }.show()
        }

        val note = TextView(this).apply {
            text = "Historical analysis only. Crash multipliers are uncertain and past results cannot predict the next round. Never bet money you cannot afford to lose."
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        page.addView(note)
    }

    private fun card(parent: LinearLayout): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = rounded(panel, 16, Color.rgb(64, 48, 78))
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(14)
        parent.addView(box, lp)
        return box
    }

    private fun label(parent: LinearLayout, value: String) {
        parent.addView(TextView(this).apply {
            text = value
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(muted)
            gravity = Gravity.CENTER
        })
    }

    private fun title(parent: LinearLayout, value: String) {
        parent.addView(TextView(this).apply {
            text = value
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(0, dp(2), 0, dp(12))
        })
    }

    private fun button(parent: LinearLayout, value: String, color: Int, textColor: Int = Color.WHITE, action: () -> Unit) {
        val b = TextView(this).apply {
            text = value
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(textColor)
            setPadding(dp(12), dp(14), dp(12), dp(14))
            background = rounded(color, 10)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(8)
        parent.addView(b, lp)
    }

    private fun statColumn(parent: LinearLayout, value: String, caption: String): TextView {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val number = TextView(this).apply {
            text = value
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(gold)
            gravity = Gravity.CENTER
        }
        col.addView(number)
        col.addView(TextView(this).apply {
            text = caption
            textSize = 10f
            setTextColor(muted)
            gravity = Gravity.CENTER
        })
        parent.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        return number
    }

    private fun addResult() {
        val value = multiplierInput.text.toString().trim().toDoubleOrNull()
        if (value == null || !value.isFinite() || value < 1.0) {
            multiplierInput.error = "Enter a valid multiplier of 1.00 or higher"
            return
        }
        results.add(0, value)
        while (results.size > 100) results.removeAt(results.lastIndex)
        saveResults()
        multiplierInput.text.clear()
        refresh()
        Toast.makeText(this, "Result saved", Toast.LENGTH_SHORT).show()
    }

    private fun analyse() {
        if (results.size < 5) {
            Toast.makeText(this, "Add at least 5 results first.", Toast.LENGTH_LONG).show()
            return
        }
        val count = when (windowSpinner.selectedItemPosition) {
            0 -> 5
            1 -> 10
            2 -> 20
            else -> 50
        }
        val recent = results.take(count)
        val avg = recent.average()
        val low = recent.count { it < 2.0 }
        val high = recent.count { it >= 2.0 }
        when {
            avg < 2.0 -> {
                signalText.text = "LOW TREND"
                signalText.setTextColor(red)
                analysisText.text = "Recent average: ${fmt(avg)}x. $low of ${recent.size} results were below 2x. This describes history, not the next round."
            }
            avg < 5.0 -> {
                signalText.text = "MEDIUM TREND"
                signalText.setTextColor(gold)
                analysisText.text = "Recent average: ${fmt(avg)}x. $high of ${recent.size} results were 2x or higher. No reliable next-round prediction."
            }
            else -> {
                signalText.text = "HIGH TREND"
                signalText.setTextColor(green)
                analysisText.text = "Recent average: ${fmt(avg)}x. The high historical average does not mean another high multiplier is due."
            }
        }
    }

    private fun refresh() {
        val avg = if (results.isEmpty()) 0.0 else results.average()
        averageText.text = "${fmt(avg)}x"
        aboveText.text = results.count { it >= 2.0 }.toString()
        totalText.text = results.size.toString()
        historyBox.removeAllViews()
        if (results.isEmpty()) {
            historyBox.addView(TextView(this).apply {
                text = "No results saved yet"
                setTextColor(muted)
                textSize = 13f
                setPadding(0, dp(8), 0, dp(8))
            })
            return
        }
        results.take(100).chunked(4).forEach { group ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            group.forEach { value ->
                val chip = TextView(this).apply {
                    text = "${fmt(value)}x"
                    textSize = 13f
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    setPadding(dp(9), dp(8), dp(9), dp(8))
                    background = rounded(panel2, 22)
                }
                val lp = LinearLayout.LayoutParams(0, -2, 1f)
                lp.setMargins(dp(3), dp(4), dp(3), dp(4))
                row.addView(chip, lp)
            }
            while (row.childCount < 4) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            historyBox.addView(row)
        }
    }

    private fun resetAnalysis() {
        signalText.text = "WAITING"
        signalText.setTextColor(gold)
        analysisText.text = "Add previous multipliers, then analyse the history."
    }

    private fun fmt(n: Double) = String.format(Locale.US, "%.2f", n)
    private fun rounded(color: Int, radius: Int, stroke: Int? = null) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != null) setStroke(dp(1), stroke)
        }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
