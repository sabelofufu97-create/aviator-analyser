# Aviator Analyser — Android project

This is a native Android application project based on the supplied Aviator Analyser.

## Features
- Add and retain up to 100 previous multipliers on the device
- Average, count above 2x, and total-round statistics
- Historical trend summaries over the last 5, 10, 20, or 50 results
- Recent result history and clear-history confirmation
- Dark mobile UI with red/gold accents
- No internet permission and no external libraries

## Build an APK
An Android SDK and Android Studio are required to compile the APK. They are not available in the build environment used to prepare this project, so this download is the complete Android Studio project source, not a compiled APK.

1. Install Android Studio on a computer.
2. Open this `AviatorAnalyser` folder in Android Studio.
3. Allow Gradle sync to finish and install Android SDK Platform 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.

For a release APK, use **Build > Generate Signed Bundle / APK** and create or select your signing key.

## Notes
- Minimum Android version: Android 6.0 (API 23).
- Application ID: `com.example.aviatoranalyser`.
- Data is stored locally using Android SharedPreferences.
- Historical multipliers cannot reliably predict future crash outcomes. The app deliberately labels its analysis as historical, not predictive.
